import * as React from "react";
import { Routes, Route } from "react-router-dom";

import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./routes/ProtectedRoute";
import GuestRoute from "./routes/GuestRoute";

import AppLayout from "./layout/AppLayout";

// Pages
import LandingPage from "./pages/LandingPage";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import MainDashboard from "./pages/MainDashboardPage";
import Diet from "./pages/Diet";
import Training from "./pages/Training";
import Habits from "./pages/Habits";
import Finance from "./pages/Finance";
import Settings from "./pages/Settings";
import UserSetting from "./components/UserSettingForm";

function App() {
  return (
    <AuthProvider>
      <AppLayout>
        <Routes>
          {/* Public */}
          <Route path="/" element={<LandingPage />} />
          <Route
            path="/login"
            element={
              <GuestRoute>
                <Login />
              </GuestRoute>
            }
          />
          <Route
            path="/register"
            element={
              <GuestRoute>
                <Register />
              </GuestRoute>
            }
          />

          {/* Protected */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          >
            <Route index element={<MainDashboard />} />
            <Route path="diet" element={<Diet />} />
            <Route path="training" element={<Training />} />
            <Route path="habits" element={<Habits />} />
            <Route path="finance" element={<Finance />} />
          </Route>

          <Route
            path="/settings"
            element={
              <ProtectedRoute>
                <Settings />
              </ProtectedRoute>
            }
          />
          <Route
            path="/userSetting"
            element={
              <ProtectedRoute>
                <UserSetting />
              </ProtectedRoute>
            }
          />
        </Routes>
      </AppLayout>
    </AuthProvider>
  );
}
export default App;