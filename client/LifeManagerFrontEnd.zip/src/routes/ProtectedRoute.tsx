import * as React from 'react';
import { Navigate, useLocation } from 'react-router-dom';

function isAuthenticated() {
  return !!(localStorage.getItem('token') || sessionStorage.getItem('token'));
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  if (!isAuthenticated()) {
    // ⬅️ místo loginu pošleme hosta na Landing
    return <Navigate to="/" replace state={{ from: location }} />;
  }
  return <>{children}</>;
}
export default ProtectedRoute;