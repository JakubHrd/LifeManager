import * as React from 'react';
import { Navigate } from 'react-router-dom';

function isAuthenticated() {
  return !!(localStorage.getItem('token') || sessionStorage.getItem('token'));
}

function GuestRoute({ children }: { children: React.ReactNode }) {
  if (isAuthenticated()) {
    return <Navigate to="/dashboard" replace />;
  }
  return <>{children}</>;
}
export default GuestRoute;