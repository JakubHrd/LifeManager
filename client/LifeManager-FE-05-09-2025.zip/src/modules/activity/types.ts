// Generické typy pro "maticové" aktivity (řádky x sloupce) řízené configem.

export type Matrix<T> = Record<string, Record<string, T>>;

export interface ActivityMatrixConfig<Cell> {
  domain: 'meals' | 'training' | 'habits' | string;
  title: string;
  api: {
    // Např. `${serverUrl}/api/meals`
    basePath: string;

    // Transformace odpovědi BE -> mřížka (řádek=day, sloupec=section) + volitelná meta
    transformIn: (raw: any) => { matrix: Matrix<Cell>; meta?: any };

    // Transformace mřížky zpět na payload pro POST (dostane i meta z transformIn)
    transformOut: (matrix: Matrix<Cell>, meta?: any) => any;
  };
  ui: {
    // Pořadí řádků a definice sloupců
    rows: string[]; // např. ['Monday', ... , 'Sunday']
    cols: Array<{ key: string; label: string }>;

    // Mapování polí v buňce + tvorba prázdné buňky
    cell: {
      textKey?: string;     // např. 'description'
      booleanKey?: string;  // např. 'eaten'
      empty: () => Cell;    // factory prázdné buňky
    };

    // Volitelné popisky
    labels?: { rowHeader?: string }; // např. 'Day'
  };
}
