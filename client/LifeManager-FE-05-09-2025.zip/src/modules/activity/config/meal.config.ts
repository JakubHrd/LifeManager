import { ActivityConfig } from '../types';
import serverUrl from '../../../config';

// Datový model řádku (bez id)
export type MealRow = {
  day: string;          // Monday ... Sunday
  section: string;      // breakfast | snack | lunch | snack2 | dinner
  description: string;
  eaten: boolean;
};

const normalizeSection = (key: string) => {
  if (key === 'launch') return 'lunch'; // BE někdy posílá "launch"
  return key;
};

const mealConfig: ActivityConfig<MealRow> = {
  type: 'meal',
  title: 'Meals',
  api: {
    // dáváme absolutní; používáš serverUrl všude, takže stejné chování
    basePath: `${serverUrl}/api/meals`,
    // transformuje { meals: { Monday: { breakfast: {...}, ... }, ... } } -> pole řádků
    transform: (raw: any) => {
      const mealsObj = raw?.meals;
      if (!mealsObj || typeof mealsObj !== 'object') return [];
      const out: MealRow[] = [];
      for (const day of Object.keys(mealsObj)) {
        const sections = mealsObj[day] ?? {};
        for (const secKey of Object.keys(sections)) {
          const sec = sections[secKey] ?? {};
          out.push({
            day,
            section: normalizeSection(secKey),
            description: String(sec.description ?? ''),
            eaten: !!sec.eaten
          });
        }
      }
      return out;
    },
    fromDto: (d: any): MealRow => ({
      day: String(d.day ?? ''),
      section: String(normalizeSection(d.section ?? '')),
      description: String(d.description ?? ''),
      eaten: !!d.eaten
    })
  },
  ui: {
    columns: [
      { key: 'day', label: 'Day' },
      { key: 'section', label: 'Meal' },
      { key: 'description', label: 'Description' },
      { key: 'eaten', label: 'Eaten' }
    ],
    getKey: (row, idx) => `${row.day}__${row.section}__${idx}`
  }
};

export default mealConfig;
