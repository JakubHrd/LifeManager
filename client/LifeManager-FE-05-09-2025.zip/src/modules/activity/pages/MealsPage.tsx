import * as React from 'react';
import { useSearchParams } from 'react-router-dom';
import { Box, Button, Typography } from '@mui/material';
import ActivityMatrix from '../components/ActivityMatrix';
import mealConfig from '../config/meal.matrix.config';

function toIsoWeek(d: Date) {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = (date.getUTCDay() + 6) % 7 + 1;
  date.setUTCDate(date.getUTCDate() + (4 - dayNum));
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const week = Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  const year = date.getUTCFullYear();
  return { week, year };
}
function fromWeekYear(week: number, year: number) {
  const simple = new Date(Date.UTC(year, 0, 1 + (week - 1) * 7));
  const dow = (simple.getUTCDay() + 6) % 7;
  simple.setUTCDate(simple.getUTCDate() - dow);
  return simple;
}

export default function MealsPage() {
  const [sp, setSp] = useSearchParams();
  const now = new Date();
  const def = toIsoWeek(now);

  const week = Number(sp.get('week') ?? def.week);
  const year = Number(sp.get('year') ?? def.year);

  const go = (w: number, y: number) => {
    const p = new URLSearchParams(sp);
    p.set('week', String(w));
    p.set('year', String(y));
    setSp(p, { replace: true });
  };
  const prevWeek = () => {
    const d = fromWeekYear(week, year);
    d.setUTCDate(d.getUTCDate() - 7);
    const p = toIsoWeek(d);
    go(p.week, p.year);
  };
  const nextWeek = () => {
    const d = fromWeekYear(week, year);
    d.setUTCDate(d.getUTCDate() + 7);
    const n = toIsoWeek(d);
    go(n.week, n.year);
  };

  return (
    <Box sx={{ p: 2 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h5">Meals — Week {week}, {year}</Typography>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button variant="outlined" onClick={prevWeek}>Prev</Button>
          <Button variant="outlined" onClick={nextWeek}>Next</Button>
        </Box>
      </Box>

      <ActivityMatrix
        config={mealConfig}
        params={{ week, year }}
      />
    </Box>
  );
}
