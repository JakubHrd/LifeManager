import * as React from 'react';
import { ActivityMatrixConfig, Matrix } from '../types';
import { ActivityApi } from '../api/base';
import {
  Box, Paper, TableContainer, Table, TableHead, TableBody, TableRow, TableCell,
  TextField, Checkbox, Button, CircularProgress, Alert
} from '@mui/material';

type Props<Cell> = {
  config: ActivityMatrixConfig<Cell>;
  params?: Record<string, string | number | boolean | undefined>; // např. { week, year }
};

export default function ActivityMatrix<Cell extends Record<string, any>>({ config, params }: Props<Cell>) {
  const [matrix, setMatrix] = React.useState<Matrix<Cell>>({});
  const [meta, setMeta] = React.useState<any>(undefined);
  const [loading, setLoading] = React.useState<boolean>(true);
  const [error, setError] = React.useState<string | null>(null);
  const [saving, setSaving] = React.useState<boolean>(false);

  // headers: token z localStorage (uprav klíč podle projektu)
  const headers = React.useCallback((): Record<string, string> => {
    const h: Record<string, string> = { 'Content-Type': 'application/json' };
    const token = localStorage.getItem('token');
    if (token) h['Authorization'] = `Bearer ${token}`;
    return h;
  }, []);

  const api = React.useMemo(
    () => new ActivityApi(config.api.basePath, { credentials: 'include', headers }),
    [config.api.basePath, headers]
  );

  const load = React.useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const raw = await api.get(params);
      const { matrix: mtx, meta: mta } = config.api.transformIn(raw);
      // doplň chybějící řádky/sloupce prázdnými buňkami (pro konzistentní UI)
      const filled: Matrix<Cell> = {};
      const empty = config.ui.cell.empty;
      for (const r of config.ui.rows) {
        const row = (mtx[r] ?? {}) as Record<string, Cell>;
        const outRow: Record<string, Cell> = {};
        for (const c of config.ui.cols) {
          outRow[c.key] = (row[c.key] ?? empty());
        }
        filled[r] = outRow;
      }
      setMatrix(filled);
      setMeta(mta);
    } catch (e: any) {
      setError(e?.message ?? 'Failed to load');
    } finally {
      setLoading(false);
    }
  }, [api, config.ui.rows, config.ui.cols, config.ui.cell.empty, config.api]);

  React.useEffect(() => { load(); }, [load, JSON.stringify(params)]);

  const save = React.useCallback(async (data: Matrix<Cell>) => {
    setSaving(true); setError(null);
    try {
      const payload = config.api.transformOut(data, meta);
      await api.post(payload, params);
    } catch (e: any) {
      setError(e?.message ?? 'Failed to save');
    } finally {
      setSaving(false);
    }
  }, [api, config.api, meta, params]);

  // Helpers pro čtení/psaní do buňky podle config.ui.cell
  const getText = (cell: Cell) => {
    const k = config.ui.cell.textKey;
    return k ? String(cell?.[k] ?? '') : '';
  };
  const setText = (cell: Cell, value: string) => {
    const k = config.ui.cell.textKey;
    if (!k) return cell;
    return { ...cell, [k]: value } as Cell;
  };
  const getBool = (cell: Cell) => {
    const k = config.ui.cell.booleanKey;
    return k ? Boolean(cell?.[k]) : false;
    };
  const setBool = (cell: Cell, value: boolean) => {
    const k = config.ui.cell.booleanKey;
    if (!k) return cell;
    return { ...cell, [k]: value } as Cell;
  };

  const onChangeText = (rowKey: string, colKey: string, value: string) => {
    setMatrix(prev => {
      const next = { ...prev, [rowKey]: { ...prev[rowKey], [colKey]: setText(prev[rowKey][colKey], value) } };
      return next;
    });
  };
  const onBlurText = async () => { await save(matrix); };

  const onToggleBool = async (rowKey: string, colKey: string) => {
    setMatrix(prev => {
      const next = { ...prev, [rowKey]: { ...prev[rowKey], [colKey]: setBool(prev[rowKey][colKey], !getBool(prev[rowKey][colKey])) } };
      return next;
    });
    await save({ ...matrix });
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }
  if (error) {
    return (
      <Box p={2}>
        <Alert severity="error">{error}</Alert>
        <Box mt={2}><Button variant="outlined" onClick={load}>Reload</Button></Box>
      </Box>
    );
  }

  return (
    <Box>
      <TableContainer component={Paper} sx={{ borderRadius: 2, boxShadow: 3 }}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontWeight: 600 }}>{config.ui.labels?.rowHeader ?? 'Day'}</TableCell>
              {config.ui.cols.map(c => (
                <TableCell key={c.key} sx={{ fontWeight: 600 }}>{c.label}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {config.ui.rows.map((rKey) => (
              <TableRow key={rKey}>
                <TableCell sx={{ fontWeight: 600 }}>{rKey}</TableCell>
                {config.ui.cols.map(c => {
                  const cell = matrix[rKey][c.key];
                  return (
                    <TableCell key={`${rKey}__${c.key}`} sx={{ verticalAlign: 'top', minWidth: 220 }}>
                      {/* Text */}
                      {config.ui.cell.textKey && (
                        <TextField
                          value={getText(cell)}
                          onChange={(e) => onChangeText(rKey, c.key, e.target.value)}
                          onBlur={onBlurText}
                          placeholder="Popis…"
                          size="small"
                          fullWidth
                          multiline
                          minRows={1}
                        />
                      )}
                      {/* Checkbox */}
                      {config.ui.cell.booleanKey && (
                        <Box mt={1}>
                          <Checkbox
                            checked={getBool(cell)}
                            onChange={() => onToggleBool(rKey, c.key)}
                          />
                          <span>Done</span>
                        </Box>
                      )}
                    </TableCell>
                  );
                })}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Box display="flex" justifyContent="flex-end" gap={1} mt={2}>
        <Button variant="outlined" onClick={() => load()}>Reset</Button>
        <Button variant="contained" disabled={saving} onClick={() => save(matrix)}>
          {saving ? 'Saving…' : 'Save'}
        </Button>
      </Box>
    </Box>
  );
}
