import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import { ActivityConfig } from '../types';
import { ActivityApi } from '../api/base';
import {
  Box, Paper, TableContainer, Table, TableHead, TableBody, TableRow, TableCell, CircularProgress, Alert
} from '@mui/material';

type Props = {
  config: ActivityConfig<any>;
  params?: Record<string, string | number | boolean | undefined>;
};

export default function ActivityList({ config, params }: Props) {
  // hlavičky pro auth (bez undefined hodnot)
  const headers = React.useCallback((): Record<string, string> => {
    const h: Record<string, string> = { 'Content-Type': 'application/json' };
    const token = localStorage.getItem('token'); // uprav klíč dle projektu
    if (token) h['Authorization'] = `Bearer ${token}`;
    return h;
  }, []);

  const api = React.useMemo(
    () => new ActivityApi(config.api.basePath, { credentials: 'include', headers }),
    [config, headers]
  );

  const { data, isLoading, error } = useQuery({
    queryKey: [config.type, 'list', params ?? {}],
    queryFn: async () => {
      const raw = await api.list(params ?? {});
      const base = Array.isArray(raw) ? raw : (raw?.items ?? raw);
      const normalized = config.api.transform
        ? config.api.transform(base)
        : (Array.isArray(base) ? base : []);
      return normalized.map(config.api.fromDto);
    }
  });

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }
  if (error) {
    return (
      <Box p={2}>
        <Alert severity="error">{String((error as Error)?.message ?? 'Failed to load')}</Alert>
      </Box>
    );
  }
  if (!data?.length) {
    return <Box p={2} sx={{ opacity: 0.7 }}>No items</Box>;
  }

  return (
    <TableContainer component={Paper} sx={{ borderRadius: 2, boxShadow: 3 }}>
      <Table size="small">
        <TableHead>
          <TableRow>
            {config.ui.columns.map((c) => (
              <TableCell key={String(c.key)}>{c.label}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((m: any, idx: number) => (
            <TableRow key={config.ui.getKey ? config.ui.getKey(m, idx) : idx}>
              {config.ui.columns.map((c) => (
                <TableCell key={String(c.key)}>
                  {String(m[c.key])}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
