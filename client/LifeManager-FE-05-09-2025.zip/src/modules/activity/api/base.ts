export interface ListParams { [k: string]: string | number | boolean | undefined }

type HeadersInitOrFn = HeadersInit | (() => HeadersInit);

export class ActivityApi {
  constructor(
    private basePath: string,
    private opts?: {
      credentials?: RequestCredentials; // 'include' pro cookies
      headers?: HeadersInitOrFn;        // např. Authorization
    }
  ) {}

  private resolveHeaders(): HeadersInit {
    const h = this.opts?.headers;
    if (!h) return {};
    return typeof h === "function" ? h() : h;
  }

  private buildUrl(params?: ListParams) {
    const qs = params && Object.keys(params).length
      ? `?${new URLSearchParams(params as any)}`
      : '';
    return `${this.basePath}${qs}`;
  }

  async get(params?: ListParams) {
    const res = await fetch(this.buildUrl(params), {
      credentials: this.opts?.credentials ?? 'include',
      headers: this.resolveHeaders()
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status} ${res.statusText}${text ? ` – ${text}` : ''}`);
    }
    return res.json();
  }

  async post(body: any, params?: ListParams) {
    const res = await fetch(this.buildUrl(params), {
      method: 'POST',
      credentials: this.opts?.credentials ?? 'include',
      headers: { 'Content-Type': 'application/json', ...this.resolveHeaders() as any },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status} ${res.statusText}${text ? ` – ${text}` : ''}`);
    }
    return res.json().catch(() => ({}));
  }
}
