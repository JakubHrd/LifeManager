export const features = {
  activityUnified: true
};
