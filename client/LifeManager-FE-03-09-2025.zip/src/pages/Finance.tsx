import React from "react";

const Finance: React.FC = () => {
  return (
    <div>
      <h2>Finance</h2>
      <p>Zde bude správa financí.</p>
    </div>
  );
};

export default Finance;
